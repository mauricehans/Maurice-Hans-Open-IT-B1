import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Panier {
    private List<Produit> produits;

    public Panier() {
        this.produits = new ArrayList<>();
    }

    public void ajouterProduit(Produit produit) {
        produits.add(produit);
    }

    public int prixTotalPanier() {
        int total = 0;
        for (Produit produit : produits) {
            total += produit.getPrix();
        }
        return total;
    }
}

class Produit {
    private String nom;
    private String description;
    private int prix;

    public Produit(String nom, String description, int prix) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public void afficher() {
        System.out.println("Nom: " + nom + ", Description: " + description + ", Prix: " + prix + "€");
    }
}

class ProduitAlimentaire extends Produit {
    private LocalDate dateExpiration;

    public ProduitAlimentaire(String nom, String description, LocalDate dateExpiration, int prix) {
        super(nom, description, prix);
        this.dateExpiration = dateExpiration;
    }

    @Override
    public void afficher() {
        super.afficher();
        System.out.println("Date d'expiration: " + dateExpiration);
    }
}

class ProduitBoisson extends Produit {

    public ProduitBoisson(String nom, String description, int prix) {
        super(nom, description, prix);
    }
}

class ProduitElectronique extends Produit {

    public ProduitElectronique(String nom, String description, int prix) {
        super(nom, description, prix);
    }
}

public class ProgrammePrincipal {

    public static void main(String[] args) {
        Produit p1 = new Produit("Stylo", "Stylo bille bleu", 1);
        p1.afficher();

        ProduitAlimentaire p2 = new ProduitAlimentaire("Yaourt", "Yaourt nature", LocalDate.of(2024, 3, 1), 2);
        p2.afficher();

        ProduitBoisson p3 = new ProduitBoisson("Eau", "Bouteille d'eau 50cl", 1);
        p3.afficher();

        ProduitElectronique p4 = new ProduitElectronique("Souris", "Souris optique USB", 15);
        p4.afficher();

        Panier panier = new Panier();
        panier.ajouterProduit(p1);
        panier.ajouterProduit(p2);
        panier.ajouterProduit(p3);
        panier.ajouterProduit(p4);

        System.out.println("Prix total panier : " + panier.prixTotalPanier() + "€");
    }
}
